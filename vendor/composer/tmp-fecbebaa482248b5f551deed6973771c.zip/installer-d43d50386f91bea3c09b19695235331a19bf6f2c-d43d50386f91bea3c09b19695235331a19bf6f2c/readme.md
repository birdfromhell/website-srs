## Installation Steps
1. Run `composer require kreativdev/installer` <br>
2. go to '{website_url}/add-installer' route<br>
<img src="https://kreativdev.com/images/add-installer.png"  width="600"> <br>
3. upload the database SQL file which will be imported after successfully installed<br>
4. Click 'Add Installer' button<br>
5. Now go to {your_website_url}. It will redirect to installer interface<br>
<img src="https://kreativdev.com/images/installer-interface.png"  width="600">