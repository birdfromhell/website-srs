<?php 

    return [
        'item_name' => "Superv",
        "item_id" => 28396210,
        "vension" => 2.2,
        "released_on" => "30th May, 2023",
        "broadcast_driver" => "pusher",
        "email_api" => 'https://kreativdev.com/emailcollector/api/collect'
    ];

?>